var values ={};
    
customApp.controller('addVendorController', function ($scope, $http) {
	
});