var values ={};
    
customApp.controller('completedTripController', function ($scope, $http) {
	
});